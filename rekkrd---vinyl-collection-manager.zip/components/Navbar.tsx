
import React from 'react';
import { Link } from 'react-router-dom';

const Navbar: React.FC = () => {
  return (
    <nav className="sticky top-0 z-50 glass-morphism py-4 px-6 md:px-12 flex justify-between items-center">
      <Link to="/" className="flex items-center space-x-2 group">
        <div className="w-8 h-8 rounded-full border-2 border-emerald-500 flex items-center justify-center animate-spin-vinyl group-hover:bg-emerald-500 transition-colors">
          <div className="w-1.5 h-1.5 bg-white rounded-full"></div>
        </div>
        <span className="font-syncopate text-xl font-bold tracking-tighter text-white">
          REKKRD
        </span>
      </Link>
      
      <div className="hidden md:flex space-x-8 font-medium">
        <a href="#features" className="hover:text-emerald-400 transition-colors">Features</a>
        <a href="#scan" className="hover:text-emerald-400 transition-colors">Scanning</a>
        <a href="#studio" className="hover:text-emerald-400 transition-colors">Studio</a>
      </div>

      <div className="flex items-center space-x-4">
        <button className="hidden sm:block px-6 py-2 rounded-full glass-morphism border border-emerald-500/30 text-emerald-400 hover:bg-emerald-500/10 transition-all font-bold">
          Log In
        </button>
        <button className="px-6 py-2 rounded-full bg-emerald-500 text-black font-bold hover:bg-emerald-400 transition-all shadow-lg shadow-emerald-500/20">
          Get Started
        </button>
      </div>
    </nav>
  );
};

export default Navbar;
