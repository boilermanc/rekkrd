
import React from 'react';

const Hero: React.FC = () => {
  return (
    <section className="relative min-h-[95vh] flex flex-col items-center justify-center text-center px-6 overflow-hidden">
      {/* Background Decor - vibrant color blooms */}
      <div className="absolute top-1/3 -left-40 w-[40rem] h-[40rem] bg-indigo-500/20 blur-[180px] rounded-full"></div>
      <div className="absolute bottom-1/3 -right-40 w-[40rem] h-[40rem] bg-emerald-500/20 blur-[180px] rounded-full"></div>

      <div className="max-w-7xl mx-auto space-y-12 relative z-10 pt-20">
        <h1 className="font-syncopate text-6xl md:text-9xl font-bold leading-none tracking-tighter text-shadow-glam text-white">
          YOUR <span className="text-emerald-400">VINYL</span><br /> 
          <span className="text-indigo-400">REIMAGINED</span>.
        </h1>
        
        <div className="max-w-3xl mx-auto px-6 py-4 glass-morphism rounded-2xl">
          <p className="text-xl md:text-2xl text-gray-100 font-light leading-relaxed text-shadow-glam">
            The ultimate crate-digging companion. Scan covers, track market value, and curate AI-powered playlists from your physical archive.
          </p>
        </div>

        <div className="flex flex-col sm:flex-row items-center justify-center space-y-6 sm:space-y-0 sm:space-x-8 pt-4">
          <button className="w-full sm:w-auto px-16 py-6 bg-emerald-500 text-black font-extrabold text-2xl rounded-full hover:bg-emerald-400 hover:scale-105 transition-all shadow-2xl shadow-emerald-500/50">
            Download Rekkrd
          </button>
          <button className="w-full sm:w-auto px-16 py-6 glass-morphism border border-white/30 text-white font-extrabold text-2xl rounded-full hover:bg-white/10 transition-all">
            Watch Demo
          </button>
        </div>

        {/* Video Placeholder */}
        <div className="mt-24 w-full max-w-5xl mx-auto aspect-video glass-morphism rounded-[2.5rem] neon-border overflow-hidden relative group cursor-pointer shadow-3xl">
          <img 
            src="https://picsum.photos/seed/vinyl-app-demo-v3/1600/900" 
            alt="App Preview" 
            className="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-all duration-700 group-hover:scale-105"
          />
          <div className="absolute inset-0 bg-black/20 group-hover:bg-black/10 transition-colors"></div>
          
          <div className="absolute inset-0 flex items-center justify-center">
             <div className="w-28 h-28 bg-emerald-500/90 backdrop-blur-xl rounded-full flex items-center justify-center border-4 border-white/20 group-hover:scale-110 transition-transform shadow-2xl">
                <svg className="w-12 h-12 text-black ml-1.5" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M8 5v14l11-7z" />
                </svg>
             </div>
          </div>
          
          <div className="absolute bottom-10 left-10 text-left bg-black/40 backdrop-blur-md p-6 rounded-2xl border border-white/10">
             <p className="text-sm font-syncopate tracking-[0.4em] text-emerald-400 uppercase mb-2">Interface Preview</p>
             <p className="text-2xl font-bold text-white text-shadow-glam">Crafting the Mood Studio</p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
