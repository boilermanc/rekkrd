
import React, { useMemo } from 'react';

const MADE_UP_TITLES = [
  "Neon Nights", "Dusty Grooves", "The Final Spin", "Velvet Echoes", "Suburban Soul", 
  "Glitch in the Wax", "Midnight Aura", "Luna Ray", "The Crate Digger", "Electric Soul",
  "Analog Dreams", "Frequency", "Hollow Point", "Solar Flare", "Static Pulse",
  "Vivid Motion", "Deep Bass Theory", "The Lost Tapes", "Rhythm & Bloom", "Ghost Notes",
  "Wax poetic", "Turntable Tales", "Spin Sector", "High Fidelity", "Mono Magic"
];

const MADE_UP_ARTISTS = [
  "The Glitch", "Vinyl Vibe", "Luna Ray", "Electric Crate", "The Diggers", 
  "System Echo", "Retro Future", "Mono Chrome", "Vapor Wave", "The 12-Inch",
  "Spin City", "Needle Drop", "Groove Theory", "Sound System", "The Mix",
  "DJ Archive", "Stereo Soul", "Freq Mod", "Phase Shift", "The Collector"
];

const CrateCollage: React.FC<{ seed: string, opacity?: number }> = ({ seed, opacity = 0.9 }) => {
  const items = useMemo(() => {
    return Array.from({ length: 54 }).map((_, i) => ({
      id: Math.floor(Math.abs(Math.sin(seed.length + i) * 80000)),
      rotation: (Math.sin(i * 5) * 8).toFixed(2),
      scale: (1.05 + Math.random() * 0.15).toFixed(2),
      title: MADE_UP_TITLES[Math.floor(Math.abs(Math.sin(i * 2.5)) * MADE_UP_TITLES.length)],
      artist: MADE_UP_ARTISTS[Math.floor(Math.abs(Math.cos(i * 3.1)) * MADE_UP_ARTISTS.length)],
      accentColor: ['#10b981', '#6366f1', '#f59e0b', '#ec4899', '#3b82f6', '#ef4444'][i % 6]
    }));
  }, [seed]);

  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none select-none z-0">
      {/* Lighter background base */}
      <div className="absolute inset-0 bg-[#0f0f12]"></div>

      {/* The Image Grid - High Brightness */}
      <div 
        className="grid grid-cols-3 md:grid-cols-6 lg:grid-cols-9 gap-3 p-4 scale-105 ken-burns will-change-transform"
        style={{ opacity }}
      >
        {items.map((item, idx) => (
          <div 
            key={idx}
            className="aspect-square relative rounded-lg overflow-hidden shadow-2xl transition-all duration-1000 bg-[#1a1a1e]"
            style={{ 
              transform: `rotate(${item.rotation}deg) scale(${item.scale})`,
              border: `1px solid ${item.accentColor}33`,
            }}
          >
            {/* Album Cover Image - Boosted Brightness */}
            <img 
              src={`https://picsum.photos/seed/rekkrd-vivid-${seed}-${item.id}/400/400`} 
              alt="Record Cover" 
              className="w-full h-full object-cover saturate-[2.2] contrast-[1.1] brightness-[1.1]"
              loading="lazy"
            />
            
            {/* Vibrant Record Labels/Titles */}
            <div className="absolute inset-0 p-3 flex flex-col justify-end bg-gradient-to-t from-black/70 via-black/10 to-transparent">
              <span className="text-[9px] md:text-[7px] font-syncopate font-bold text-white truncate leading-tight tracking-wider" style={{ textShadow: '0 1px 4px rgba(0,0,0,1)' }}>
                {item.title}
              </span>
              <span className="text-[7px] md:text-[5px] font-syncopate font-medium text-white/70 truncate uppercase tracking-widest mt-0.5" style={{ color: item.accentColor }}>
                {item.artist}
              </span>
            </div>
            
            {/* Top Shine */}
            <div className="absolute inset-0 bg-gradient-to-br from-white/20 via-transparent to-black/20 opacity-40"></div>
          </div>
        ))}
      </div>
      
      {/* 1. Lightening Overlay - Uses screen blending to make everything brighter */}
      <div className="absolute inset-0 bg-white/[0.03] mix-blend-screen"></div>

      {/* 2. Soft Focal Gradient - Only darkens the far edges */}
      <div className="absolute inset-0 bg-radial-glow opacity-80"></div>
      
      {/* 3. Section Transitions - Subtle fades */}
      <div className="absolute bottom-0 left-0 w-full h-40 bg-gradient-to-t from-[#050505] via-[#050505]/40 to-transparent"></div>
      <div className="absolute top-0 left-0 w-full h-40 bg-gradient-to-b from-[#050505] via-[#050505]/30 to-transparent"></div>

      {/* 4. High-Vibrance Accent Clouds */}
      <div className="absolute top-1/4 left-1/4 w-[70%] h-[70%] bg-emerald-500/10 blur-[200px] rounded-full"></div>
      <div className="absolute bottom-1/4 right-1/4 w-[70%] h-[70%] bg-indigo-500/10 blur-[200px] rounded-full"></div>
    </div>
  );
};

export default CrateCollage;
