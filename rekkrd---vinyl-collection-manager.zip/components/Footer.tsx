
import React from 'react';
import { Link } from 'react-router-dom';

const Footer: React.FC = () => {
  return (
    <footer className="bg-black py-16 px-6 border-t border-white/5">
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-12">
        <div className="space-y-6">
          <Link to="/" className="flex items-center space-x-2">
            <div className="w-6 h-6 rounded-full border border-emerald-500 flex items-center justify-center animate-spin-vinyl">
              <div className="w-1 h-1 bg-white rounded-full"></div>
            </div>
            <span className="font-syncopate text-lg font-bold tracking-tighter text-white">REKKRD</span>
          </Link>
          <p className="text-gray-500 text-sm leading-relaxed">
            Revolutionizing the way you manage and enjoy your physical record collection. Built for crate diggers, by crate diggers.
          </p>
        </div>
        
        <div>
          <h4 className="font-syncopate text-xs font-bold text-emerald-500 mb-6 uppercase tracking-[0.2em]">Product</h4>
          <ul className="space-y-4 text-sm text-gray-400">
            <li><a href="#features" className="hover:text-white transition-colors">Features</a></li>
            <li><a href="#studio" className="hover:text-white transition-colors">Playlist Studio</a></li>
            <li><a href="#" className="hover:text-white transition-colors">Integrations</a></li>
          </ul>
        </div>

        <div>
          <h4 className="font-syncopate text-xs font-bold text-emerald-500 mb-6 uppercase tracking-[0.2em]">Legal</h4>
          <ul className="space-y-4 text-sm text-gray-400">
            <li><Link to="/terms" className="hover:text-white transition-colors">Terms of Service</Link></li>
            <li><Link to="/privacy" className="hover:text-white transition-colors">Privacy Policy</Link></li>
            <li><Link to="/support" className="hover:text-white transition-colors">Cookie Policy</Link></li>
          </ul>
        </div>

        <div>
          <h4 className="font-syncopate text-xs font-bold text-emerald-500 mb-6 uppercase tracking-[0.2em]">Connect</h4>
          <ul className="space-y-4 text-sm text-gray-400">
            <li><Link to="/support" className="hover:text-white transition-colors">Support Center</Link></li>
            <li><a href="#" className="hover:text-white transition-colors">Twitter / X</a></li>
            <li><a href="#" className="hover:text-white transition-colors">Instagram</a></li>
          </ul>
        </div>
      </div>
      
      <div className="max-w-7xl mx-auto mt-16 pt-8 border-t border-white/5 flex flex-col md:flex-row justify-between items-center text-xs text-gray-600 font-syncopate tracking-widest uppercase">
        <p>&copy; {new Date().getFullYear()} REKKRD LTD. ALL RIGHTS RESERVED.</p>
        <div className="flex space-x-6 mt-4 md:mt-0">
          <span className="text-emerald-500">System Status: Online</span>
          <span>Made in SF</span>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
