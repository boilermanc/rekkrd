
import React from 'react';

const FeatureCard = ({ title, description, icon, tag }: { title: string, description: string, icon: React.ReactNode, tag?: string }) => (
  <div className="glass-morphism p-8 rounded-2xl border border-white/5 hover:border-emerald-500/30 transition-all group">
    <div className="mb-6 p-4 w-16 h-16 rounded-xl bg-white/5 text-emerald-400 group-hover:bg-emerald-500 group-hover:text-black transition-all">
      {icon}
    </div>
    {tag && <span className="text-[10px] font-syncopate text-indigo-400 uppercase tracking-widest mb-2 block">{tag}</span>}
    <h3 className="font-syncopate text-xl font-bold mb-4">{title}</h3>
    <p className="text-gray-400 leading-relaxed font-light">
      {description}
    </p>
  </div>
);

const Features: React.FC = () => {
  return (
    <section id="features" className="py-24 px-6 max-w-7xl mx-auto">
      <div className="text-center mb-20">
        <h2 className="font-syncopate text-3xl md:text-5xl font-bold mb-6">MORE THAN JUST A <span className="text-emerald-500">LIST</span>.</h2>
        <div className="h-1 w-20 bg-emerald-500 mx-auto"></div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <FeatureCard 
          tag="Scan & Enrich"
          title="Instant ID"
          description="Point your camera at any album cover. Our AI identifies artist, album, genre, and even fetches high-quality art instantly."
          icon={
            <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" />
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" />
            </svg>
          }
        />
        <FeatureCard 
          tag="Valuation"
          title="Portfolio Value"
          description="Sync with Discogs data to see low, median, and high market prices. Watch your collection grow into a portfolio."
          icon={
            <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
            </svg>
          }
        />
        <FeatureCard 
          tag="AI Narrative"
          title="The Narrative"
          description="Get poetic, AI-written descriptions for every album in your crate. Deepen your connection with the music you love."
          icon={
            <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
            </svg>
          }
        />
      </div>

      <div className="mt-24 glass-morphism rounded-3xl p-8 md:p-16 flex flex-col md:flex-row items-center gap-12 border border-white/5">
        <div className="md:w-1/2 space-y-6">
           <span className="text-sm font-syncopate text-emerald-400 tracking-widest uppercase">Mood-Based Magic</span>
           <h3 className="text-3xl md:text-5xl font-bold font-syncopate">PLAYLIST STUDIO</h3>
           <p className="text-xl text-gray-400 leading-relaxed font-light">
             Set a mood like "Rainy Day Jazz" or "High-Energy Soul" and let Rekkrd curate a perfect playlist exclusively from your collection. No hallucinations, just your records, perfectly sequenced.
           </p>
           <ul className="space-y-4 pt-4">
             <li className="flex items-center space-x-3 text-emerald-400">
               <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd"></path></svg>
               <span className="text-white">Full Album or Individual Side curation</span>
             </li>
             <li className="flex items-center space-x-3 text-emerald-400">
               <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd"></path></svg>
               <span className="text-white">Print beautiful PDF manifest cards</span>
             </li>
           </ul>
        </div>
        <div className="md:w-1/2 relative group">
           <div className="absolute inset-0 bg-emerald-500/20 blur-[60px] rounded-full group-hover:bg-emerald-500/30 transition-all"></div>
           <div className="relative glass-morphism p-4 rounded-3xl neon-border rotate-3 group-hover:rotate-0 transition-transform duration-500">
              <img src="https://picsum.photos/seed/playlist/600/400" alt="Playlist Studio" className="rounded-2xl" />
           </div>
        </div>
      </div>
    </section>
  );
};

export default Features;
