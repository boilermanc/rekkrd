
import React, { useState } from 'react';
import CrateCollage from '../components/VinylBackground';

const FAQItem = ({ question, answer }: { question: string, answer: string }) => {
  const [isOpen, setIsOpen] = useState(false);
  return (
    <div className="glass-morphism rounded-2xl overflow-hidden border border-white/10 shadow-lg">
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="w-full p-8 text-left flex justify-between items-center hover:bg-white/5 transition-colors"
      >
        <span className="font-syncopate text-sm font-bold tracking-wider uppercase text-white text-shadow-glam">{question}</span>
        <svg className={`w-6 h-6 text-emerald-400 transform transition-transform ${isOpen ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
        </svg>
      </button>
      {isOpen && (
        <div className="px-8 pb-8 text-gray-200 font-light leading-relaxed text-lg border-t border-white/5 pt-4">
          {answer}
        </div>
      )}
    </div>
  );
};

const SupportPage: React.FC = () => {
  return (
    <div className="relative min-h-screen bg-[#050505]">
      <CrateCollage seed="support-vibe" opacity={0.4} />
      
      <div className="relative z-10 py-32 px-6 max-w-6xl mx-auto">
        <div className="text-center mb-24">
          <h1 className="font-syncopate text-5xl md:text-8xl font-bold mb-8 text-white text-shadow-glam">HELP & <span className="text-emerald-400">SUPPORT</span></h1>
          <p className="text-gray-200 text-2xl font-light text-shadow-glam">Need a hand with your crate? Our specialists are spinning the wheels for you.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 mb-32">
          <div className="glass-morphism p-10 rounded-[2.5rem] border border-white/10 neon-border shadow-2xl backdrop-blur-3xl">
            <div className="w-16 h-16 bg-emerald-500/20 rounded-2xl flex items-center justify-center mb-8">
              <svg className="w-8 h-8 text-emerald-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
              </svg>
            </div>
            <h2 className="font-syncopate text-2xl font-bold mb-6 text-white text-shadow-glam tracking-tight">EMAIL SUPPORT</h2>
            <p className="text-gray-300 font-light mb-10 text-lg leading-relaxed">
              Facing a glitch? Our tech team responds to all inquiries in under 4 hours during business days.
            </p>
            <a href="mailto:support@rekkrd.io" className="block text-center px-10 py-5 bg-emerald-500 text-black font-extrabold rounded-2xl hover:bg-emerald-400 transition-all shadow-xl shadow-emerald-500/30 text-xl">
              Open Support Ticket
            </a>
          </div>

          <div className="glass-morphism p-10 rounded-[2.5rem] border border-white/10 shadow-2xl backdrop-blur-3xl">
             <div className="w-16 h-16 bg-indigo-500/20 rounded-2xl flex items-center justify-center mb-8">
               <svg className="w-8 h-8 text-indigo-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" />
              </svg>
            </div>
            <h2 className="font-syncopate text-2xl font-bold mb-6 text-white text-shadow-glam tracking-tight">COMMUNITY DISCORD</h2>
            <p className="text-gray-300 font-light mb-10 text-lg leading-relaxed">
              Connect with 15k+ crate diggers. Share your latest hauls and get instant help from fellow collectors.
            </p>
            <button className="w-full px-10 py-5 glass-morphism border border-white/20 text-white font-extrabold rounded-2xl hover:bg-white/10 transition-all text-xl">
              Join the Discord
            </button>
          </div>
        </div>

        <div className="space-y-6">
          <h3 className="font-syncopate text-3xl font-bold mb-12 text-white text-shadow-glam">THE <span className="text-emerald-400">FAQ</span> VAULT</h3>
          <div className="grid gap-6">
            <FAQItem 
              question="How accurate is the camera scan?" 
              answer="Rekkrd's AI identification engine is trained on over 50 million album covers. It identifies specific pressings with 99.4% accuracy for studio releases. Rare test pressings or damaged covers might require a quick manual search."
            />
            <FAQItem 
              question="Can I sync across multiple devices?" 
              answer="Absolutely. Your collection is securely archived in the Rekkrd cloud. Log in on any device to see your crate, valuation data, and AI-curated playlists."
            />
            <FAQItem 
              question="Where do the market prices come from?" 
              answer="We pull real-time data from global marketplaces like Discogs and eBay, specifically tracking verified 'sold' listings to give you an accurate low, median, and high valuation based on condition."
            />
            <FAQItem 
              question="Is my data private?" 
              answer="We are collectors, not data brokers. Your collection information and personal notes are private by default and never sold. You own your data."
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default SupportPage;
