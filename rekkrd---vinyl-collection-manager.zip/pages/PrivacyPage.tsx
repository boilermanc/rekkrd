
import React from 'react';
import CrateCollage from '../components/VinylBackground';

const PrivacyPage: React.FC = () => {
  return (
    <div className="relative min-h-screen bg-[#050505]">
      <CrateCollage seed="privacy-wax" opacity={0.3} />
      
      <div className="relative z-10 py-32 px-6 max-w-4xl mx-auto">
        <h1 className="font-syncopate text-5xl font-bold mb-16 text-indigo-400 text-shadow-glam">PRIVACY <span className="text-white">POLICY</span></h1>
        
        <div className="glass-morphism p-10 md:p-16 rounded-[3rem] space-y-12 font-light leading-relaxed text-gray-200 shadow-2xl backdrop-blur-3xl border border-white/10">
          <section>
            <h2 className="font-syncopate text-2xl font-bold text-white mb-6 tracking-tight">1. DATA HARVESTING</h2>
            <p className="text-lg">We only collect what makes the app work. This includes your email (for your account), your collection metadata, and any photos you snap of album covers. We do not track your location or sell your identity to third parties.</p>
          </section>

          <section>
            <h2 className="font-syncopate text-2xl font-bold text-white mb-6 tracking-tight">2. HOW WE USE YOUR INFO</h2>
            <p className="text-lg">Your data is used to calculate your portfolio value, generate AI-narratives for your albums, and curate playlists. We use anonymized usage patterns to improve our scanning algorithms.</p>
          </section>

          <section>
            <h2 className="font-syncopate text-2xl font-bold text-white mb-6 tracking-tight">3. AI PROCESSING</h2>
            <p className="text-lg">Scanning an album involves temporary image processing. These images are discarded immediately after identification unless you choose to save them as your primary album art.</p>
          </section>

          <section>
            <h2 className="font-syncopate text-2xl font-bold text-white mb-6 tracking-tight">4. SECURITY</h2>
            <p className="text-lg">We use industry-standard encryption to protect your crate. While we take every precaution, no system is perfectly immutable. We recommend using unique passwords for your Rekkrd account.</p>
          </section>
          
          <div className="pt-12 border-t border-white/10 text-sm text-gray-500 font-syncopate uppercase tracking-[0.3em]">
            Revision 2.1.0 | Updated JUNE 2024
          </div>
        </div>
      </div>
    </div>
  );
};

export default PrivacyPage;
