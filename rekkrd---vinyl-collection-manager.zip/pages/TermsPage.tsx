
import React from 'react';
import CrateCollage from '../components/VinylBackground';

const TermsPage: React.FC = () => {
  return (
    <div className="relative min-h-screen bg-[#050505]">
      <CrateCollage seed="legal-wax" opacity={0.3} />
      
      <div className="relative z-10 py-32 px-6 max-w-4xl mx-auto">
        <h1 className="font-syncopate text-5xl font-bold mb-16 text-emerald-400 text-shadow-glam">TERMS & <span className="text-white">CONDITIONS</span></h1>
        
        <div className="glass-morphism p-10 md:p-16 rounded-[3rem] space-y-12 font-light leading-relaxed text-gray-200 shadow-2xl backdrop-blur-3xl border border-white/10">
          <section>
            <h2 className="font-syncopate text-2xl font-bold text-white mb-6 tracking-tight">1. ACCEPTANCE OF TERMS</h2>
            <p className="text-lg">By accessing or using Rekkrd, you agree to be bound by these terms. This is a binding agreement between you and Rekkrd Ltd. If you do not agree, please do not spin with us.</p>
          </section>

          <section>
            <h2 className="font-syncopate text-2xl font-bold text-white mb-6 tracking-tight">2. THE SERVICE</h2>
            <p className="text-lg">Rekkrd is a management platform for music collectors. While our AI identification is cutting-edge, we provide information for recreational and organizational purposes only. Valuation data is an estimate, not a financial guarantee.</p>
          </section>

          <section>
            <h2 className="font-syncopate text-2xl font-bold text-white mb-6 tracking-tight">3. USER CONDUCT</h2>
            <p className="text-lg">You are responsible for any metadata or notes you add to your collection. We reserve the right to ban users who attempt to scrape our pricing data or disrupt the community experience.</p>
          </section>

          <section>
            <h2 className="font-syncopate text-2xl font-bold text-white mb-6 tracking-tight">4. INTELLECTUAL PROPERTY</h2>
            <p className="text-lg">The "Rekkrd" brand and software are our property. Metadata fetched from partner APIs remains the property of those entities (Discogs, MusicBrainz, etc.).</p>
          </section>
          
          <div className="pt-12 border-t border-white/10 text-sm text-gray-500 font-syncopate uppercase tracking-[0.3em]">
            Revision 1.0.4 | Updated MAY 2024
          </div>
        </div>
      </div>
    </div>
  );
};

export default TermsPage;
