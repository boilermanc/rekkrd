
import React from 'react';
import Hero from '../components/Hero';
import Features from '../components/Features';
import CrateCollage from '../components/VinylBackground';

const LandingPage: React.FC = () => {
  return (
    <div className="relative bg-[#050505] w-full min-h-screen">
      {/* Hero Section */}
      <div className="relative min-h-screen flex items-center justify-center">
        <CrateCollage seed="hero-high-key" opacity={1.0} />
        <div className="relative z-10 w-full">
          <Hero />
        </div>
      </div>
      
      {/* Features Section */}
      <div className="relative border-t border-white/10 py-32">
        <CrateCollage seed="features-vivid" opacity={0.6} />
        <div className="relative z-10 w-full">
          <Features />
        </div>
      </div>
      
      {/* CTA Section */}
      <section className="py-48 px-6 relative overflow-hidden border-t border-white/10">
        <CrateCollage seed="cta-vibrant" opacity={0.9} />
        
        <div className="max-w-4xl mx-auto glass-morphism p-12 md:p-24 rounded-[3rem] text-center neon-border relative z-10 shadow-3xl">
           <div className="inline-block px-5 py-1.5 rounded-full bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 text-xs font-syncopate uppercase tracking-widest mb-10">
             V0.9 PRE-RELEASE
           </div>
           <h2 className="font-syncopate text-4xl md:text-7xl font-bold mb-10 leading-tight text-white text-shadow-glam">
             READY TO <span className="text-emerald-400">DIGITIZE</span><br /> YOUR SOUL?
           </h2>
           <p className="text-xl md:text-2xl text-gray-200 font-light mb-16 max-w-2xl mx-auto leading-relaxed text-shadow-glam">
             Stop hunting through dusty shelves. Start spinning your favorites in seconds with Rekkrd's AI-enhanced collection manager.
           </p>
           <div className="flex flex-col sm:flex-row gap-8 justify-center">
              <button className="px-16 py-6 bg-emerald-500 text-black font-extrabold rounded-full text-2xl hover:bg-emerald-400 hover:scale-105 transition-all shadow-2xl shadow-emerald-500/60">
                Join the Crate
              </button>
              <button className="px-16 py-6 glass-morphism border border-white/20 text-white font-extrabold rounded-full text-2xl hover:bg-white/10 transition-all">
                The Roadmap
              </button>
           </div>
        </div>
      </section>

      {/* Trust Section */}
      <section className="py-32 px-6 border-t border-white/10 relative overflow-hidden">
        <CrateCollage seed="partners-light" opacity={0.3} />
        <div className="max-w-7xl mx-auto text-center relative z-10">
           <p className="font-syncopate text-[10px] tracking-[0.5em] text-gray-400 uppercase mb-20 opacity-80">Global Recognition</p>
           <div className="grid grid-cols-2 md:grid-cols-5 gap-16 items-center opacity-90 brightness-150">
             <span className="font-syncopate text-2xl font-bold italic text-white/90 text-shadow-glam">VinylMePlease</span>
             <span className="font-syncopate text-2xl font-bold text-white/90 text-shadow-glam">Pitchfork</span>
             <span className="font-syncopate text-2xl font-bold uppercase text-white/90 text-shadow-glam">The Verge</span>
             <span className="font-syncopate text-2xl font-bold text-white/90 text-shadow-glam">WIRED</span>
             <span className="font-syncopate text-2xl font-bold text-white/90 text-shadow-glam">HYPEBEAST</span>
           </div>
        </div>
      </section>
    </div>
  );
};

export default LandingPage;
